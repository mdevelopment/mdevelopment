module.exports = {
    mongoURI: "mongodb://localhost:27017/mdevelopment",
    secretOrKey: 'secret'
};